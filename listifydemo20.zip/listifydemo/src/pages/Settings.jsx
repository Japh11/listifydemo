import React from 'react';

function Settings() {
    return <div><h2>Settings Page</h2></div>;
}

export default Settings;
