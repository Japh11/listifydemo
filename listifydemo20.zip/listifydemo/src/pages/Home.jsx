// src/pages/Home.js
import React from 'react';
import './Home.css';
import logo from '../assets/logo.png'; // Ensure the logo path is correct

function Home() {
    const handleGetStarted = () => {
        // Implement the logic to navigate to the desired page or functionality
        console.log("Get Started button clicked");
    };

    return (
        <div className="home">
            <header className="home-header">
                <div className="welcome-container">
                    <h1>Welcome to </h1>
                    <img src={logo} alt="logo" className="logo" />
                </div>
                <p>Organize your tasks and schedule efficiently</p>
            </header>

            <section className="home-intro">
                <div className="feature">
                    <h2>📅 Calendar</h2>
                    <p>View and manage your tasks on an interactive calendar.</p>
                </div>
                <div className="feature">
                    <h2>📝 Tasks</h2>
                    <p>Keep track of tasks, mark them as done, and prioritize.</p>
                </div>
                <div className="feature">
                    <h2>⚙️ Settings</h2>
                    <p>Customize your app experience and preferences.</p>
                </div>
            </section>

            <section className="cta-section">
                <button className="cta-button" onClick={handleGetStarted}>
                    Get Started
                </button>
            </section>
        </div>
    );
}

export default Home;
