import React from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import './App.css';
import logo from './assets/logo.png';

// Import components
import Home from './pages/Home'; // Import the Home component
import CalendarPage from './pages/Calendar';
import Tasks from './pages/Tasks';

function Settings() {
    return <div><h2>Settings Page</h2></div>;
}

function App() {
    return (
        <Router>
            <div className="container">
                <div className="sidebar">
                    <div className="logo-container">
                        <img src={logo} alt="logo" className="logo" />
                    </div>
                    
                    <ul>
                        <li>
                            <NavLink
                                to="/calendar"
                                className={({ isActive }) => isActive ? 'active-link' : ''}
                            >
                                CALENDAR
                            </NavLink>
                        </li>
                        <li>
                            <NavLink
                                to="/tasks"
                                className={({ isActive }) => isActive ? 'active-link' : ''}
                            >
                                TASKS
                            </NavLink>
                        </li>
                        <li>
                            <NavLink
                                to="/settings"
                                className={({ isActive }) => isActive ? 'active-link' : ''}
                            >
                                SETTINGS
                            </NavLink>
                        </li>
                    </ul>
                </div>

                <div className="main-content">
                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/calendar" element={<CalendarPage />} />
                        <Route path="/tasks" element={<Tasks />} />
                        <Route path="/settings" element={<Settings />} />
                    </Routes>
                </div>
            </div>
        </Router>
    );
}

export default App;
